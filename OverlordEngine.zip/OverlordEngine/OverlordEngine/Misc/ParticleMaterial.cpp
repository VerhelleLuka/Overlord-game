#include "stdafx.h"
#include "ParticleMaterial.h"

ParticleMaterial::ParticleMaterial():
Material(L"Effects/ParticleRenderer.fx")
{
}

void ParticleMaterial::InitializeEffectVariables()
{
}
