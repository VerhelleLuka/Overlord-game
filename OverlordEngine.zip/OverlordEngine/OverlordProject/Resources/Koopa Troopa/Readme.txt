Here is Koopa Troopa from Mario 64.
If you use this could you give credit to Alec Pike, or at least try to remember my name?
If you have any comments or complaints or need help with the model or something e-mail me at alec.pike@gmail.com

---------

This model was fixed to an unanimated pose by Zerox. No credit necessary for that though.